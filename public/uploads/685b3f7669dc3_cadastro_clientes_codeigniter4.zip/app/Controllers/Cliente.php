<?php
namespace App\Controllers;
use App\Models\ClienteModel;
use CodeIgniter\Controller;
class Cliente extends BaseController
{
    public function index()
    {
        $model = new ClienteModel();
        $data['clientes'] = $model->findAll();
        return view('cliente/list', $data);
    }
    public function create()
    {
        return view('cliente/form');
    }
    public function store()
    {
        $validation = \Config\Services::validation();
        $input = $this->validate([
            'nome' => 'required|min_length[3]',
            'email' => 'required|valid_email',
            'telefone' => 'required',
            'foto' => 'uploaded[foto]|is_image[foto]|max_size[foto,1024]'
        ]);
        if (!$input) {
            return view('cliente/form', ['validation' => $this->validator]);
        }
        $foto = $this->request->getFile('foto');
        $nomeFoto = null;
        if ($foto->isValid() && !$foto->hasMoved()) {
            $nomeFoto = $foto->getRandomName();
            $foto->move('uploads/', $nomeFoto);
        }
        $model = new ClienteModel();
        $model->save([
            'nome' => $this->request->getPost('nome'),
            'email' => $this->request->getPost('email'),
            'telefone' => $this->request->getPost('telefone'),
            'foto' => $nomeFoto
        ]);
        return redirect()->to('/cliente');
    }
    public function edit($id)
    {
        $model = new ClienteModel();
        $data['cliente'] = $model->find($id);
        return view('cliente/form', $data);
    }
    public function update($id)
    {
        $model = new ClienteModel();
        $cliente = $model->find($id);
        $validation = \Config\Services::validation();
        $input = $this->validate([
            'nome' => 'required|min_length[3]',
            'email' => 'required|valid_email',
            'telefone' => 'required',
            'foto' => 'if_exist|is_image[foto]|max_size[foto,1024]'
        ]);
        if (!$input) {
            return view('cliente/form', ['validation' => $this->validator, 'cliente' => $cliente]);
        }
        $foto = $this->request->getFile('foto');
        $nomeFoto = $cliente['foto'];
        if ($foto && $foto->isValid() && !$foto->hasMoved()) {
            if ($nomeFoto && file_exists('uploads/' . $nomeFoto)) {
                unlink('uploads/' . $nomeFoto);
            }
            $nomeFoto = $foto->getRandomName();
            $foto->move('uploads/', $nomeFoto);
        }
        $model->update($id, [
            'nome' => $this->request->getPost('nome'),
            'email' => $this->request->getPost('email'),
            'telefone' => $this->request->getPost('telefone'),
            'foto' => $nomeFoto
        ]);
        return redirect()->to('/cliente');
    }
    public function delete($id)
    {
        $model = new ClienteModel();
        $cliente = $model->find($id);
        if ($cliente['foto'] && file_exists('uploads/' . $cliente['foto'])) {
            unlink('uploads/' . $cliente['foto']);
        }
        $model->delete($id);
        return redirect()->to('/cliente');
    }
}