<!DOCTYPE html>
<html>
<head>
    <title><?= isset($cliente) ? 'Editar' : 'Novo' ?> Cliente</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="container mt-5">
    <h2><?= isset($cliente) ? 'Editar' : 'Novo' ?> Cliente</h2>
    <?php if(isset($validation)): ?>
        <div class="alert alert-danger"><?= $validation->listErrors() ?></div>
    <?php endif; ?>
    <form action="<?= isset($cliente) ? '/cliente/update/'.$cliente['id'] : '/cliente/store' ?>" method="post" enctype="multipart/form-data">
        <div class="mb-3">
            <label>Nome</label>
            <input type="text" name="nome" class="form-control" value="<?= isset($cliente) ? esc($cliente['nome']) : '' ?>">
        </div>
        <div class="mb-3">
            <label>Email</label>
            <input type="email" name="email" class="form-control" value="<?= isset($cliente) ? esc($cliente['email']) : '' ?>">
        </div>
        <div class="mb-3">
            <label>Telefone</label>
            <input type="text" name="telefone" class="form-control" value="<?= isset($cliente) ? esc($cliente['telefone']) : '' ?>">
        </div>
        <div class="mb-3">
            <label>Foto</label>
            <input type="file" name="foto" class="form-control">
            <?php if(isset($cliente) && $cliente['foto']): ?>
                <img src="<?= base_url('uploads/'.$cliente['foto']) ?>" width="100" class="mt-2">
            <?php endif; ?>
        </div>
        <button class="btn btn-primary" type="submit">Salvar</button>
        <a href="/cliente" class="btn btn-secondary">Voltar</a>
    </form>
</body>
</html>