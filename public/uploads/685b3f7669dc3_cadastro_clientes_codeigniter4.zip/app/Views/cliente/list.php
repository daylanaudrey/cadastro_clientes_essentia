<!DOCTYPE html>
<html>
<head>
    <title>Clientes</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="container mt-5">
    <h2>Lista de Clientes</h2>
    <a href="/cliente/create" class="btn btn-success mb-3">Novo Cliente</a>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Foto</th>
                <th>Nome</th>
                <th>Email</th>
                <th>Telefone</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($clientes as $cliente): ?>
                <tr>
                    <td>
                        <?php if($cliente['foto']): ?>
                            <img src="<?= base_url('uploads/'.$cliente['foto']) ?>" width="60">
                        <?php else: ?>
                            <span>Sem foto</span>
                        <?php endif; ?>
                    </td>
                    <td><?= esc($cliente['nome']) ?></td>
                    <td><?= esc($cliente['email']) ?></td>
                    <td><?= esc($cliente['telefone']) ?></td>
                    <td>
                        <a href="/cliente/edit/<?= $cliente['id'] ?>" class="btn btn-primary btn-sm">Editar</a>
                        <a href="/cliente/delete/<?= $cliente['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>